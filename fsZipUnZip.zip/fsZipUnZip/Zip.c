#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "Zip.h"

void zip(const char* input_filename, const char* output_filename) {
    //opens input file same like the cat command 
    FILE* input = fopen(input_filename, "r");
    FILE* output = fopen(output_filename, "w");
    //if input or output is null creates an error 
    if (input == NULL || output == NULL) {
        printf("Error opening files");
        return;
    }

    int count = 1; // Initialize count to 1
    // sets the char variables to null
    char ch, prev_ch = '\0';
    //reads characters from the input file to the end of file 
    while ((ch = fgetc(input)) != EOF) {
        if (ch == prev_ch) {
            count++; // if current character is the same as the previous one increment it 
        } else {
            if (count > 1) {
                fprintf(output, "%d%c", count, prev_ch); // Write count and character to output
            } else {
                fputc(prev_ch, output); // Writes the character to output
            }
            count = 1; // Resets count for the new character
        }
        prev_ch = ch;
    }

    // Handles the last character
    if (count > 1) {
        fprintf(output, "%d%c", count, prev_ch); // Write count and character to output
    } else {
        fputc(prev_ch, output); // Write the character to output
    }

    fclose(input);
    fclose(output);
}


