
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "UnZip.h"
// same idea as zip but it decompresses 
void UnZip(const char* input_filename, const char* output_filename) {
    FILE* input = fopen(input_filename, "r");
    FILE* output = fopen(output_filename, "w");

    if (input == NULL || output == NULL) {
        perror("Error opening files");
        return;
    }

    int count = 0;
    int ch;

    while ((ch = fgetc(input)) != EOF) {
        if (isdigit(ch)) {
            count = count * 10 + (ch - '0');
        } else {
            for (int i = 0; i < count; i++) {
                fputc(ch, output);
            }
            count = 0;
        }
    }

    fclose(input);
    fclose(output);
}

