/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   UnZip.h
 * Author: student
 *
 * Created on October 8, 2023, 9:18 PM
 */

#ifndef UNZIP_H
#define UNZIP_H

#ifdef __cplusplus
extern "C" {
#endif

void UnZip(const char* input_filename, const char* output_filename);


#ifdef __cplusplus
}
#endif

#endif /* UNZIP_H */

