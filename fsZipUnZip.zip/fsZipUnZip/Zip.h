/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   Zip.h
 * Author: student
 *
 * Created on October 8, 2023, 9:06 PM
 */

#ifndef ZIP_H
#define ZIP_H

#ifdef __cplusplus
extern "C" {
#endif

    void zip(const char* input_filename, const char* output_filename);


#ifdef __cplusplus
}
#endif

#endif /* ZIP_H */

