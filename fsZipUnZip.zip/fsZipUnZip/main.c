/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   main.c
 * Author: student
 *
 * Created on October 8, 2023, 8:07 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "Zip.h"
#include "UnZip.h"

/*
 * 
 */
int main(int argc, char* argv[]) {
    //checks if there are four arguments 
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <input_file> <compressed_file> <decompressed_file>\n", argv[0]);
        return 1;
    }

    const char* input_file = argv[1]; // this is supposed to store the name of the input file
    const char* compressed_file = argv[2]; // this is supposed to store the name of the compressed file 
    const char* decompressed_file = argv[3]; // this is supposed to store the name of the decompressed file 

    // compressed the input file
    zip(input_file, compressed_file);

    //decompresses the input file 
    UnZip(compressed_file, decompressed_file);

    return 0;
}

